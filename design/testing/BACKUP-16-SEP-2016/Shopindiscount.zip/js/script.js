// Code goes here
var app = angular.module('myApp', ['ngMaterial', 'jkAngularCarousel', 'ngRoute'])


app.controller('MyCtrl', function($scope, $http) {


    $scope.dataArray = [{
        src: 'images/slider/banner-4-750x400.jpg'
    }, {
        src: 'images/slider/banner-1-750x400.jpg'
    }, {
        src: 'images/slider/banner-2-750x400.jpg'
    }, {
        src: 'images/slider/banner-3-750x400.jpg'
    }];




    /* $http.get('home_slider.json').success(function(data) {
           $scope.product_slide_a1 = data;
    console.log($scope.product_slide_a1);
         });*/




    $scope.product_slide_a1 = [{
        "title": "Seductive by Guess For Women - Eau De Toilette, 75ml",
        "thum_img": "images/product/img1.jpg",
        "price": "Rs.25,000",
        "alt_val": "i phone"
    }, {
        "title": "Beauty by Calvin Klein For Women - Eau De Parfum 100ml",
        "thum_img": "images/product/img2.jpg",
        "price": "Rs.13,000",
        "alt_val": "i phone"
    }, {
        "title": "Google Chromecast 2 HDMI Streaming Media Player - Black",
        "thum_img": "images/product/img3.jpg",
        "price": "Rs.7,000",
        "alt_val": "i phone"
    }, {
        "title": "Grand Theft Auto V By Rockstar For PlayStation 4",
        "thum_img": "images/product/img4.jpg",
        "price": "Rs.42,000",
        "alt_val": "i phone"
    }, {
        "title": "Google Chromecast 2 HDMI Streaming Media Player - Black",
        "thum_img": "images/product/img3.jpg",
        "price": "Rs.7,000",
        "alt_val": "i phone"
    }, {
        "title": "Grand Theft Auto V By Rockstar For PlayStation 4",
        "thum_img": "images/product/img4.jpg",
        "price": "Rs.42,000"
    }, {
        "title": "Google Chromecast 2 HDMI Streaming Media Player - Black",
        "thum_img": "images/product/img3.jpg",
        "price": "Rs.7,000"
    }, {
        "title": "Grand Theft Auto V By Rockstar For PlayStation 4",
        "thum_img": "images/product/img4.jpg",
        "price": "Rs.42,000"
    }, {
        "title": "Cool Water by Davidoff For Men - Eau De Toilette, 125ml ",
        "thum_img": "images/product/img5.jpg",
        "price": "Rs.3,000"
    }]


    /*--------- popular product*/
    $scope.po_product_slide_a1 = [{
            title: 'Calvin Klein Euphoria Men Intense for Men (100ml Eau de Toilette)',
            thum_img: 'images/product/img1a.jpg',
            price: 'Rs.25,000'
        }, {
            title: 'Seductive Homme By Guess for Men - Eau De Toilette, 100ml',
            thum_img: 'images/product/img2a.jpg',
            price: 'Rs.13,000'
        }, {
            title: 'Mn Cosmetics Matte Kiss Proof lipstick, set of 12 pieces - P130..',
            thum_img: 'images/product/img3a.jpg',
            price: 'Rs.7,000'
        }, {
            title: 'VR Box VRO Virtual Reality 3D Glasses with Bluetooth',
            thum_img: 'images/product/img4a.jpg',
            price: 'Rs.42,000'
        }, {
            title: 'Sonashi Simply Straight Hair Brush Straightener',
            thum_img: 'images/product/img5a.jpg',
            price: 'Rs.3,000'
        }, {
            title: 'Calvin Klein Euphoria Men Intense for Men (100ml Eau de Toilette)',
            thum_img: 'images/product/img1a.jpg',
            price: 'Rs.25,000'
        }, {
            title: 'Seductive Homme By Guess for Men - Eau De Toilette, 100ml',
            thum_img: 'images/product/img2a.jpg',
            price: 'Rs.13,000'
        }, {
            title: 'Mn Cosmetics Matte Kiss Proof lipstick, set of 12 pieces - P130..',
            thum_img: 'images/product/img3a.jpg',
            price: 'Rs.7,000'
        }

    ];

    /*--------- popular product electronics part 1 */

    $scope.e_product_slide_a_lap = [

        {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.99',
            off_p: '5% Off'
        }, {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.99',
            off_p: '5% Off'
        }, {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.99',
            off_p: '5% Off'
        }, {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.99',
            off_p: '5% Off'
        }, {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.99',
            off_p: '5% Off'
        }, {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.99',
            off_p: '5% Off'
        }

    ];
    /*--------- popular product electronics part 2 */
    $scope.e_product_slide_a_desk = [

        {
            title: 'Hp Pavilion G6 2314ax Notebok Laptop',
            thum_img: 'images/product/ipod_shuffle_1-200x200.jpg',
            price: 'Rs.122.00'
        }, {
            title: 'Hp Pavilion G6 2314ax Notebok Laptop',
            thum_img: 'images/product/ipod_shuffle_1-200x200.jpg',
            price: 'Rs.122.00'
        }, {
            title: 'Hp Pavilion G6 2314ax Notebok Laptop',
            thum_img: 'images/product/ipod_shuffle_1-200x200.jpg',
            price: 'Rs.122.00'
        }, {
            title: 'Hp Pavilion G6 2314ax Notebok Laptop',
            thum_img: 'images/product/ipod_shuffle_1-200x200.jpg',
            price: 'Rs.122.00'
        }, {
            title: 'Hp Pavilion G6 2314ax Notebok Laptop',
            thum_img: 'images/product/ipod_shuffle_1-200x200.jpg',
            price: 'Rs.122.00'
        }, {
            title: 'Hp Pavilion G6 2314ax Notebok Laptop',
            thum_img: 'images/product/ipod_shuffle_1-200x200.jpg',
            price: 'Rs.122.00'
        }
    ];
    /*--------- popular product electronics part 3 */
    $scope.e_product_slide_a_came = [

        {
            title: 'FinePix S8400W Long Zoom Camera',
            thum_img: 'images/product/FinePix-Long-Zoom-Camera-200x200.jpg',
            price: 'Rs.122.00'
        }, {
            title: 'Digital Camera for Elderly',
            thum_img: 'images/product/nikon_d300_1-200x200.jpg',
            price: 'Rs.92.00',
            d_price: 'Rs.98.00',
            off_p: '6% Off'
        }, {
            title: 'FinePix S8400W Long Zoom Camera',
            thum_img: 'images/product/FinePix-Long-Zoom-Camera-200x200.jpg',
            price: 'Rs.122.00'
        }, {
            title: 'Digital Camera for Elderly',
            thum_img: 'images/product/nikon_d300_1-200x200.jpg',
            price: 'Rs.92.00',
            d_price: 'Rs.98.00',
            off_p: '6% Off'
        }, {
            title: 'FinePix S8400W Long Zoom Camera',
            thum_img: 'images/product/FinePix-Long-Zoom-Camera-200x200.jpg',
            price: 'Rs.122.00'
        }, {
            title: 'Digital Camera for Elderly',
            thum_img: 'images/product/nikon_d300_1-200x200.jpg',
            price: 'Rs.92.00',
            d_price: 'Rs.98.00',
            off_p: '6% Off'
        }, {
            title: 'FinePix S8400W Long Zoom Camera',
            thum_img: 'images/product/FinePix-Long-Zoom-Camera-200x200.jpg',
            price: 'Rs.122.00'
        }, {
            title: 'Digital Camera for Elderly',
            thum_img: 'images/product/nikon_d300_1-200x200.jpg',
            price: 'Rs.92.00',
            d_price: 'Rs.98.00',
            off_p: '6% Off'
        }
    ];
    /*--------- popular product electronics part 4 */
    $scope.e_product_slide_a_phon = [

        {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.00',
            off_p: '5% Off'
        }, {
            title: 'iPhone5',
            thum_img: 'images/product/iphone_1-200x200.jpg',
            price: '$123.20'
        }, {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.00',
            off_p: '5% Off'
        }, {
            title: 'iPhone5',
            thum_img: 'images/product/iphone_1-200x200.jpg',
            price: '$123.20'
        }, {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.00',
            off_p: '5% Off'
        }, {
            title: 'iPhone5',
            thum_img: 'images/product/iphone_1-200x200.jpg',
            price: '$123.20'
        }, {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.00',
            off_p: '5% Off'
        }, {
            title: 'iPhone5',
            thum_img: 'images/product/iphone_1-200x200.jpg',
            price: '$123.20'
        }
    ];
    /*--------- popular product electronics part 5 */
    $scope.e_product_slide_a_tv = [

        {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.00',
            off_p: '5% Off'
        }, {
            title: 'Portable Mp3 Player',
            thum_img: 'images/product/ipod_classic_1-200x200.jpg',
            price: 'Rs.122.20'
        }, {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.00',
            off_p: '5% Off'
        }, {
            title: 'Portable Mp3 Player',
            thum_img: 'images/product/ipod_classic_1-200x200.jpg',
            price: 'Rs.122.20'
        }, {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.00',
            off_p: '5% Off'
        }, {
            title: 'Portable Mp3 Player',
            thum_img: 'images/product/ipod_classic_1-200x200.jpg',
            price: 'Rs.122.20'
        }, {
            title: 'Aspire Ultrabook Laptop',
            thum_img: 'images/product/samsung_tab_1-200x200.jpg',
            price: 'Rs.230.00',
            d_price: 'Rs.241.00',
            off_p: '5% Off'
        }, {
            title: 'Portable Mp3 Player',
            thum_img: 'images/product/ipod_classic_1-200x200.jpg',
            price: 'Rs.122.20'
        }
    ];
    /*--------- popular product electronics part 6 */
    $scope.e_product_slide_a_mp3 = [

        {
            title: 'Portable Mp3 Player',
            thum_img: 'images/product/ipod_classic_1-200x200.jpg',
            price: 'Rs.122.20'
        }, {
            title: 'Mp3 Player',
            thum_img: 'images/product/ipod_nano_1-200x200.jpg',
            price: 'Rs.122.20'
        }, {
            title: 'Portable Mp3 Player',
            thum_img: 'images/product/ipod_classic_1-200x200.jpg',
            price: 'Rs.122.20'
        }, {
            title: 'Mp3 Player',
            thum_img: 'images/product/ipod_nano_1-200x200.jpg',
            price: 'Rs.122.20'
        }, {
            title: 'Portable Mp3 Player',
            thum_img: 'images/product/ipod_classic_1-200x200.jpg',
            price: 'Rs.122.20'
        }, {
            title: 'Mp3 Player',
            thum_img: 'images/product/ipod_nano_1-200x200.jpg',
            price: 'Rs.122.20'
        }, {
            title: 'Portable Mp3 Player',
            thum_img: 'images/product/ipod_classic_1-200x200.jpg',
            price: 'Rs.122.20'
        }, {
            title: 'Mp3 Player',
            thum_img: 'images/product/ipod_nano_1-200x200.jpg',
            price: 'Rs.122.20'
        }
    ];

    /*-------- product Health and beauty part 6 */

    $scope.e_product_slide_a_health1 = [

        {
            title: 'Hair Care Cream for Men',
            thum_img: 'images/product/iphone_6-200x200.jpg',
            price: 'Rs.134.00'
        }
    ];
    $scope.e_product_slide_a_health2 = [

        {
            title: 'Hair Care Products',
            thum_img: 'images/product/nikon_d300_5-200x200.jpg',
            price: 'Rs.66.80',
            d_price: 'Rs.90.80',
            off_p: '-27%'
        }
    ];
    $scope.e_product_slide_a_health3 = [

        {
            title: 'Bed Head Foxy Curls Contour Cream',
            thum_img: 'images/product/nikon_d300_4-200x200.jpg',
            price: 'Rs.88.00'
        }
    ];
    $scope.e_product_slide_a_health4 = [

        {
            title: 'Shower Gel Perfume for Women',
            thum_img: 'images/product/macbook_5-200x200.jpg',
            price: 'Rs.95.00',
            d_price: 'Rs.99.00',
            off_p: '-4%'
        }
    ];
    $scope.e_product_slide_a_health5 = [

        {
            title: 'Perfumes for Women',
            thum_img: 'images/product/macbook_4-200x200.jpg',
            price: '$85.00'
        }
    ];
    $scope.e_product_slide_a_health6 = [

        {
            title: 'Make Up for Naturally Beautiful Better',
            thum_img: 'images/product/macbook_3-200x200.jpg',
            price: '$123.00'
        }
    ];
    $scope.e_product_slide_a_health7 = [

        {
            title: 'Pnina Tornai Perfume',
            thum_img: 'images/product/macbook_2-200x200.jpg',
            price: 'Rs.110.00'
        }
    ];



    /*-----------------------------------------------------------------------------------------------------------------*/




    /* Product category start*/


    $scope.shop_by_cat = [{
            title: 'Television',
            prdct_img: 'images/product/telivision.jpg'
        },

        {
            title: 'Camera',
            prdct_img: 'images/product/camera.jpg'
        },

        {
            title: 'Home Audio',
            prdct_img: 'images/product/audio.jpg'
        },

        {
            title: 'HeadPhones',
            prdct_img: 'images/product/headphone.jpg'
        }
    ];

    $scope.shop_by_cat2 = [{
            title: 'Projectors',
            prdct_img2: 'images/product/projector.jpg'
        },

        {
            title: 'Speakers',
            prdct_img2: 'images/product/speaker.jpg'
        },

        {
            title: 'Data Storage',
            prdct_img2: 'images/product/data_storage.jpg'
        },

        {
            title: 'Sequerty Equipments',
            prdct_img2: 'images/product/security.jpg'
        }
    ];



    $scope.shop_by_brand = [{
            brnd_img: 'images/brand/samsung.jpg'
        },

        {
            brnd_img: 'images/brand/sony.jpg'
        },

        {
            brnd_img: 'images/brand/lg.jpg'
        },

        {
            brnd_img: 'images/brand/apple.jpg'
        },

        {
            brnd_img: 'images/brand/chrome.jpg'
        },

        {
            brnd_img: 'images/brand/bose.jpg'
        }
    ];

    $scope.shop_by_brand2 = [

        {
            brnd_img2: 'images/brand/braun.jpg'
        },

        {
            brnd_img2: 'images/brand/canon.jpg'
        },

        {
            brnd_img2: 'images/brand/gopro.jpg'
        },

        {
            brnd_img2: 'images/brand/hisense.jpg'
        },

        {
            brnd_img2: 'images/brand/jbl.jpg'
        },

        {
            brnd_img2: 'images/brand/samsung.jpg'
        }
    ];


    /*product category json end*/

    /*product subcategory json start*/
    $scope.sub_cat_offer = [

        {
            labl_dscnt: 'Special Offer',
            labl_cnt: '40'
        }, {
            labl_dscnt: 'Bulk Discount',
            labl_cnt: '25'
        }, {
            labl_dscnt: 'Bulk Discount',
            labl_cnt: '25'
        }, {
            labl_dscnt: 'Store Discount',
            labl_cnt: '85'
        }

    ];

    $scope.sub_cat_brand = [

        {
            sub_brand: 'Alonsa',
            sub_cnt: '1'
        }, {
            sub_brand: 'Bmsatellite',
            sub_cnt: '1'
        }, {
            sub_brand: 'Changhong',
            sub_cnt: '1'
        }, {
            sub_brand: 'Disney',
            sub_cnt: '7'
        }, {
            sub_brand: 'Elekta',
            sub_cnt: '1'
        }, {
            sub_brand: 'Eurostar',
            sub_cnt: '6'
        }, {
            sub_brand: 'Geevox',
            sub_cnt: '1'
        }, {
            sub_brand: 'General Gold',
            sub_cnt: '1'
        }, {
            sub_brand: 'Haier',
            sub_cnt: '1'
        }

    ];

    $scope.sub_cat_screen = [

        {
            sub_screen: '7',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '9.0',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '9.5',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '13.0Inch',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '14Inch',
            sub_screen_inchs: '3'
        }, {
            sub_screen: '15.0Inch',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '17 Inch',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '19 Inch',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '20',
            sub_screen_inchs: '3'
        }

    ];

    $scope.sub_cat_color = [

        {
            sub_color: 'Black',
            sub_color_cnt: '268'
        }, {
            sub_color: 'Blue',
            sub_color_cnt: '1'
        }, {
            sub_color: 'Gold',
            sub_color_cnt: '1'
        }, {
            sub_color: 'Grey',
            sub_color_cnt: '2'
        }, {
            sub_color: 'Pink',
            sub_color_cnt: '1'
        }, {
            sub_color: 'Red',
            sub_color_cnt: '3'
        }, {
            sub_color: 'Silver',
            sub_color_cnt: '15'
        }, {
            sub_color: 'White',
            sub_color_cnt: '1'
        }

    ];

    $scope.sub_cat_typ = [

        {
            sub_typ: 'Android Tv',
            sub_typ_cnt: '9'
        }, {
            sub_typ: 'HD',
            sub_typ_cnt: '1'
        }, {
            sub_typ: 'Smart',
            sub_typ_cnt: '2'
        }, {
            sub_typ: 'Smart3D TV',
            sub_typ_cnt: '3'
        }, {
            sub_typ: 'SmartTv',
            sub_typ_cnt: '41'
        }, {
            sub_typ: 'StandardTv',
            sub_typ_cnt: '32'
        }, {
            sub_typ: '3D Tv',
            sub_typ_cnt: '5'
        }, {
            sub_typ: '4K Uhd',
            sub_typ_cnt: '1'
        }

    ];

    $scope.sub_cat_res = [

        {
            sub_res: '1920X1080',
            sub_res_cnt: '22'
        }, {
            sub_res: '3840X2160',
            sub_res_cnt: '19'
        }, {
            sub_res: '1366X768',
            sub_res_cnt: '15'
        }, {
            sub_res: '3840X2160',
            sub_res_cnt: '9'
        }, {
            sub_res: '1920X180',
            sub_res_cnt: '4'
        }, {
            sub_res: '1280X720',
            sub_res_cnt: '3'
        }, {
            sub_res: '720X576',
            sub_res_cnt: '2'
        }, {
            sub_res: '1024X768',
            sub_res_cnt: '1'
        }, {
            sub_res: '1920X1080(full Hd)',
            sub_res_cnt: '1'
        }

    ];

    $scope.sub_cat_price = [

        {
            sub_price: 'Less than Rs.10,000'
        }, {
            sub_price: 'Rs.10,000 - Rs.30,000'
        }, {
            sub_price: 'Rs.30,000 - Rs.50,000'
        }, {
            sub_price: 'Rs.50,000 - Rs.70,000'
        }, {
            sub_price: 'More Than  Rs.70,000'
        }

    ];

    $scope.sub_cat_prd_th = [

        {
            sub_img: 'images/eye.png',
            sub_prdct_image: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt: '10',
            price_old: 'Rs.50,000.00',
            price_new: 'Rs.25,000.00',
            saving: '50% Off',
            similar: 'See Similar Products'
        }, {
            sub_img: 'images/eye.png',
            sub_prdct_image: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt: '10',
            price_old: 'Rs.50,000.00',
            price_new: 'Rs.25,000.00',
            saving: '50% Off',
            similar: 'See Similar Products'
        }, {
            sub_img: 'images/eye.png',
            sub_prdct_image: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt: '10',
            price_old: 'Rs.50,000.00',
            price_new: 'Rs.25,000.00',
            saving: '50% Off',
            similar: 'See Similar Products'
        }, {
            sub_img: 'images/eye.png',
            sub_prdct_image: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt: '10',
            price_old: 'Rs.50,000.00',
            price_new: 'Rs.25,000.00',
            saving: '50% Off',
            similar: 'See Similar Products'
        }, {
            sub_img: 'images/eye.png',
            sub_prdct_image: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt: '10',
            price_old: 'Rs.50,000.00',
            price_new: 'Rs.25,000.00',
            saving: '50% Off',
            similar: 'See Similar Products'
        }



    ];

    $scope.sub_cat_prd_top = [

        {
            sub_img1: 'images/eye.png',
            sub_prdct_image1: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt2: '10',
            price_old2: 'Rs.30,000.00',
            price_new2: 'Rs.28,000.00',
            saving2: '20% Off',
            similar2: 'See Similar Products'
        }, {
            sub_img1: 'images/eye.png',
            sub_prdct_image1: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt2: '10',
            price_old2: 'Rs.30,000.00',
            price_new2: 'Rs.28,000.00',
            saving2: '20% Off',
            similar2: 'See Similar Products'
        }, {
            sub_img1: 'images/eye.png',
            sub_prdct_image1: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt2: '10',
            price_old2: 'Rs.30,000.00',
            price_new2: 'Rs.28,000.00',
            saving2: '20% Off',
            similar2: 'See Similar Products'
        }, {
            sub_img1: 'images/eye.png',
            sub_prdct_image1: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt2: '10',
            price_old2: 'Rs.30,000.00',
            price_new2: 'Rs.28,000.00',
            saving2: '20% Off',
            similar2: 'See Similar Products'
        }, {
            sub_img1: 'images/eye.png',
            sub_prdct_image1: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt2: '10',
            price_old2: 'Rs.30,000.00',
            price_new2: 'Rs.28,000.00',
            saving2: '20% Off',
            similar2: 'See Similar Products'
        }

    ];

    $scope.sub_cat_prd_newnes = [

        {
            sub_img_new: 'images/eye.png',
            sub_prdct_image_new: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt_new: '10',
            price_old_new: 'Rs.50,000.00',
            price_newnes: 'Rs.25,000.00',
            saving_new: '50% Off',
            similar_new: 'See Similar Products'
        }, {
            sub_img_new: 'images/eye.png',
            sub_prdct_image_new: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt_new: '10',
            price_old_new: 'Rs.50,000.00',
            price_newnes: 'Rs.25,000.00',
            saving_new: '50% Off',
            similar_new: 'See Similar Products'
        }, {
            sub_img_new: 'images/eye.png',
            sub_prdct_image_new: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt_new: '10',
            price_old_new: 'Rs.50,000.00',
            price_newnes: 'Rs.25,000.00',
            saving_new: '50% Off',
            similar_new: 'See Similar Products'
        }, {
            sub_img_new: 'images/eye.png',
            sub_prdct_image_new: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt_new: '10',
            price_old_new: 'Rs.50,000.00',
            price_newnes: 'Rs.25,000.00',
            saving_new: '50% Off',
            similar_new: 'See Similar Products'
        }, {
            sub_img_new: 'images/eye.png',
            sub_prdct_image_new: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt_new: '10',
            price_old_new: 'Rs.50,000.00',
            price_newnes: 'Rs.25,000.00',
            saving_new: '50% Off',
            similar_new: 'See Similar Products'
        }


    ];

    $scope.sub_cat_prd_newness2 = [

        {
            sub_img_new2: 'images/eye.png',
            sub_prdct_image_new2: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt_new2: '10',
            price_old_new2: 'Rs.30,000.00',
            price_newnes2: 'Rs.28,000.00',
            saving_new2: '20% Off',
            similar_new2: 'See Similar Products'
        }, {
            sub_img_new2: 'images/eye.png',
            sub_prdct_image_new2: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt_new2: '10',
            price_old_new2: 'Rs.30,000.00',
            price_newnes2: 'Rs.28,000.00',
            saving_new2: '20% Off',
            similar_new2: 'See Similar Products'
        }, {
            sub_img_new2: 'images/eye.png',
            sub_prdct_image_new2: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt_new2: '10',
            price_old_new2: 'Rs.30,000.00',
            price_newnes2: 'Rs.28,000.00',
            saving_new2: '20% Off',
            similar_new2: 'See Similar Products'
        }, {
            sub_img_new2: 'images/eye.png',
            sub_prdct_image_new2: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt_new2: '10',
            price_old_new2: 'Rs.30,000.00',
            price_newnes2: 'Rs.28,000.00',
            saving_new2: '20% Off',
            similar_new2: 'See Similar Products'
        }, {
            sub_img_new2: 'images/eye.png',
            sub_prdct_image_new2: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt_new2: '10',
            price_old_new2: 'Rs.30,000.00',
            price_newnes2: 'Rs.28,000.00',
            saving_new2: '20% Off',
            similar_new2: 'See Similar Products'
        }

    ];


    /*product subcategory json end*/

    /*product subcategory compare json start*/


    $scope.sub_cat_compbrand = [

        {
            sub_brand: 'Alonsa',
            sub_cnt: '1'
        }, {
            sub_brand: 'Bmsatellite',
            sub_cnt: '1'
        }, {
            sub_brand: 'Changhong',
            sub_cnt: '1'
        }, {
            sub_brand: 'Disney',
            sub_cnt: '7'
        }, {
            sub_brand: 'Elekta',
            sub_cnt: '1'
        }, {
            sub_brand: 'Eurostar',
            sub_cnt: '6'
        }, {
            sub_brand: 'Geevox',
            sub_cnt: '1'
        }, {
            sub_brand: 'General Gold',
            sub_cnt: '1'
        }, {
            sub_brand: 'Haier',
            sub_cnt: '1'
        }

    ];

    $scope.sub_cat_compscreen = [

        {
            sub_screen: '7',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '9.0',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '9.5',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '13.0Inch',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '14Inch',
            sub_screen_inchs: '3'
        }, {
            sub_screen: '15.0Inch',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '17 Inch',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '19 Inch',
            sub_screen_inchs: '1'
        }, {
            sub_screen: '20',
            sub_screen_inchs: '3'
        }

    ];

    $scope.sub_cat_compcolor = [

        {
            sub_color: 'Black',
            sub_color_cnt: '268'
        }, {
            sub_color: 'Blue',
            sub_color_cnt: '1'
        }, {
            sub_color: 'Gold',
            sub_color_cnt: '1'
        }, {
            sub_color: 'Grey',
            sub_color_cnt: '2'
        }, {
            sub_color: 'Pink',
            sub_color_cnt: '1'
        }, {
            sub_color: 'Red',
            sub_color_cnt: '3'
        }, {
            sub_color: 'Silver',
            sub_color_cnt: '15'
        }, {
            sub_color: 'White',
            sub_color_cnt: '1'
        }

    ];

    $scope.sub_cat_comptyp = [

        {
            sub_typ: 'Android Tv',
            sub_typ_cnt: '9'
        }, {
            sub_typ: 'HD',
            sub_typ_cnt: '1'
        }, {
            sub_typ: 'Smart',
            sub_typ_cnt: '2'
        }, {
            sub_typ: 'Smart3D TV',
            sub_typ_cnt: '3'
        }, {
            sub_typ: 'SmartTv',
            sub_typ_cnt: '41'
        }, {
            sub_typ: 'StandardTv',
            sub_typ_cnt: '32'
        }, {
            sub_typ: '3D Tv',
            sub_typ_cnt: '5'
        }, {
            sub_typ: '4K Uhd',
            sub_typ_cnt: '1'
        }

    ];

    $scope.sub_cat_compres = [

        {
            sub_res: '1920X1080',
            sub_res_cnt: '22'
        }, {
            sub_res: '3840X2160',
            sub_res_cnt: '19'
        }, {
            sub_res: '1366X768',
            sub_res_cnt: '15'
        }, {
            sub_res: '3840X2160',
            sub_res_cnt: '9'
        }, {
            sub_res: '1920X180',
            sub_res_cnt: '4'
        }, {
            sub_res: '1280X720',
            sub_res_cnt: '3'
        }, {
            sub_res: '720X576',
            sub_res_cnt: '2'
        }, {
            sub_res: '1024X768',
            sub_res_cnt: '1'
        }, {
            sub_res: '1920X1080(full Hd)',
            sub_res_cnt: '1'
        }

    ];

    $scope.sub_cat_compprice = [

        {
            sub_price: 'Less than Rs.10,000'
        }, {
            sub_price: 'Rs.10,000 - Rs.30,000'
        }, {
            sub_price: 'Rs.30,000 - Rs.50,000'
        }, {
            sub_price: 'Rs.50,000 - Rs.70,000'
        }, {
            sub_price: 'More Than  Rs.70,000'
        }

    ];

    $scope.sub_cat_prd_th1 = [

        {
            sub_img: 'images/eye.png',
            sub_prdct_image: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt: '10',
            price_old: 'Rs.50,000.00',
            price_new: 'Rs.25,000.00',
            saving: '50% Off',
            similar: 'See Similar Products'
        }, {
            sub_img: 'images/eye.png',
            sub_prdct_image: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt: '10',
            price_old: 'Rs.50,000.00',
            price_new: 'Rs.25,000.00',
            saving: '50% Off',
            similar: 'See Similar Products'
        }, {
            sub_img: 'images/eye.png',
            sub_prdct_image: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt: '10',
            price_old: 'Rs.50,000.00',
            price_new: 'Rs.25,000.00',
            saving: '50% Off',
            similar: 'See Similar Products'
        }, {
            sub_img: 'images/eye.png',
            sub_prdct_image: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt: '10',
            price_old: 'Rs.50,000.00',
            price_new: 'Rs.25,000.00',
            saving: '50% Off',
            similar: 'See Similar Products'
        }, {
            sub_img: 'images/eye.png',
            sub_prdct_image: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt: '10',
            price_old: 'Rs.50,000.00',
            price_new: 'Rs.25,000.00',
            saving: '50% Off',
            similar: 'See Similar Products'
        }

    ];

    $scope.sub_cat_prd_top1 = [

        {
            sub_img1: 'images/eye.png',
            sub_prdct_image1: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt2: '10',
            price_old2: 'Rs.30,000.00',
            price_new2: 'Rs.28,000.00',
            saving2: '20% Off',
            similar2: 'See Similar Products'
        }, {
            sub_img1: 'images/eye.png',
            sub_prdct_image1: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt2: '10',
            price_old2: 'Rs.30,000.00',
            price_new2: 'Rs.28,000.00',
            saving2: '20% Off',
            similar2: 'See Similar Products'
        }, {
            sub_img1: 'images/eye.png',
            sub_prdct_image1: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt2: '10',
            price_old2: 'Rs.30,000.00',
            price_new2: 'Rs.28,000.00',
            saving2: '20% Off',
            similar2: 'See Similar Products'
        }, {
            sub_img1: 'images/eye.png',
            sub_prdct_image1: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt2: '10',
            price_old2: 'Rs.30,000.00',
            price_new2: 'Rs.28,000.00',
            saving2: '20% Off',
            similar2: 'See Similar Products'
        }, {
            sub_img1: 'images/eye.png',
            sub_prdct_image1: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt2: '10',
            price_old2: 'Rs.30,000.00',
            price_new2: 'Rs.28,000.00',
            saving2: '20% Off',
            similar2: 'See Similar Products'
        }

    ];



    $scope.sub_cat_prd_newnes1 = [

        {
            sub_img_new: 'images/eye.png',
            sub_prdct_image_new: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt_new: '10',
            price_old_new: 'Rs.50,000.00',
            price_newnes: 'Rs.25,000.00',
            saving_new: '50% Off',
            similar_new: 'See Similar Products'
        }, {
            sub_img_new: 'images/eye.png',
            sub_prdct_image_new: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt_new: '10',
            price_old_new: 'Rs.50,000.00',
            price_newnes: 'Rs.25,000.00',
            saving_new: '50% Off',
            similar_new: 'See Similar Products'
        }, {
            sub_img_new: 'images/eye.png',
            sub_prdct_image_new: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt_new: '10',
            price_old_new: 'Rs.50,000.00',
            price_newnes: 'Rs.25,000.00',
            saving_new: '50% Off',
            similar_new: 'See Similar Products'
        }, {
            sub_img_new: 'images/eye.png',
            sub_prdct_image_new: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt_new: '10',
            price_old_new: 'Rs.50,000.00',
            price_newnes: 'Rs.25,000.00',
            saving_new: '50% Off',
            similar_new: 'See Similar Products'
        }, {
            sub_img_new: 'images/eye.png',
            sub_prdct_image_new: 'images/product/Samsung-28-Slim-LED-UA-28J4100-210x210.jpg',
            tittle: 'Samsung 28 Inch HD Slim LED TV (UA-28J4100)',
            str_cnt_new: '10',
            price_old_new: 'Rs.50,000.00',
            price_newnes: 'Rs.25,000.00',
            saving_new: '50% Off',
            similar_new: 'See Similar Products'
        }


    ];


    $scope.sub_cat_prd_newness22 = [

        {
            sub_img_new2: 'images/eye.png',
            sub_prdct_image_new2: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt_new2: '10',
            price_old_new2: 'Rs.30,000.00',
            price_newnes2: 'Rs.28,000.00',
            saving_new2: '20% Off',
            similar_new2: 'See Similar Products'
        }, {
            sub_img_new2: 'images/eye.png',
            sub_prdct_image_new2: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt_new2: '10',
            price_old_new2: 'Rs.30,000.00',
            price_newnes2: 'Rs.28,000.00',
            saving_new2: '20% Off',
            similar_new2: 'See Similar Products'
        }, {
            sub_img_new2: 'images/eye.png',
            sub_prdct_image_new2: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt_new2: '10',
            price_old_new2: 'Rs.30,000.00',
            price_newnes2: 'Rs.28,000.00',
            saving_new2: '20% Off',
            similar_new2: 'See Similar Products'
        }, {
            sub_img_new2: 'images/eye.png',
            sub_prdct_image_new2: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt_new2: '10',
            price_old_new2: 'Rs.30,000.00',
            price_newnes2: 'Rs.28,000.00',
            saving_new2: '20% Off',
            similar_new2: 'See Similar Products'
        }, {
            sub_img_new2: 'images/eye.png',
            sub_prdct_image_new2: 'images/product/macbook_air_1-210x210.jpg',
            tittle: 'Laptop Silver black',
            str_cnt_new2: '10',
            price_old_new2: 'Rs.30,000.00',
            price_newnes2: 'Rs.28,000.00',
            saving_new2: '20% Off',
            similar_new2: 'See Similar Products'
        }

    ];


    /*product subcategory compare json end*/




    /*------------------------------------------------Json Data----------------------------------------------------------------------*/


});

// I lazily load the images, when they come into view.

app.directive(
    "bnLazySrc",
    function($window, $document) {
        // I manage all the images that are currently being
        // monitored on the page for lazy loading.
        var lazyLoader = (function() {
            // I maintain a list of images that lazy-loading
            // and have yet to be rendered.
            var images = [];
            // I define the render timer for the lazy loading
            // images to that the DOM-querying (for offsets)
            // is chunked in groups.
            var renderTimer = null;
            var renderDelay = 1000;
            // I cache the window element as a jQuery reference.
            var win = $($window);
            // I cache the document document height so that 
            // we can respond to changes in the height due to
            // dynamic content.
            var doc = $document;
            var documentHeight = doc.height();
            var documentTimer = null;
            var documentDelay = 1000;
            // I determine if the window dimension events 
            // (ie. resize, scroll) are currenlty being 
            // monitored for changes.
            var isWatchingWindow = false;
            // I start monitoring the given image for visibility
            // and then render it when necessary.
            function addImage(image) {
                images.push(image);
                if (!renderTimer) {
                    startRenderTimer();
                }
                if (!isWatchingWindow) {
                    startWatchingWindow();
                }
            }
            // I remove the given image from the render queue.
            function removeImage(image) {
                // Remove the given image from the render queue.
                for (var i = 0; i < images.length; i++) {
                    if (images[i] === image) {
                        images.splice(i, 1);
                        break;
                    }
                }
                // If removing the given image has cleared the
                // render queue, then we can stop monitoring 
                // the window and the image queue.
                if (!images.length) {
                    clearRenderTimer();
                    stopWatchingWindow();
                }
            }
            // I check the document height to see if it's changed.
            function checkDocumentHeight() {
                // If the render time is currently active, then 
                // don't bother getting the document height - 
                // it won't actually do anything.
                if (renderTimer) {
                    return;
                }
                var currentDocumentHeight = doc.height();
                // If the height has not changed, then ignore - 
                // no more images could have come into view.
                if (currentDocumentHeight === documentHeight) {
                    return;
                }
                // Cache the new document height.
                documentHeight = currentDocumentHeight;
                startRenderTimer();
            }
            // I check the lazy-load images that have yet to 
            // be rendered. 
            function checkImages() {
                // Log here so we can see how often this 
                // gets called during page activity.
                console.log("Checking for visible images...");
                var visible = [];
                var hidden = [];

                // Determine the window dimensions.
                var windowHeight = win.height();
                var scrollTop = win.scrollTop();

                // Calculate the viewport offsets.
                var topFoldOffset = scrollTop;
                var bottomFoldOffset = (topFoldOffset + windowHeight);
                // Query the DOM for layout and seperate the
                // images into two different categories: those
                // that are now in the viewport and those that
                // still remain hidden.
                for (var i = 0; i < images.length; i++) {

                    var image = images[i];
                    if (image.isVisible(topFoldOffset, bottomFoldOffset)) {
                        visible.push(image);
                    } else {
                        hidden.push(image);
                    }
                }
                // Update the DOM with new image source values.
                for (var i = 0; i < visible.length; i++) {
                    visible[i].render();
                }
                // Keep the still-hidden images as the new 
                // image queue to be monitored.
                images = hidden;
                // Clear the render timer so that it can be set
                // again in response to window changes.
                clearRenderTimer();
                // If we've rendered all the images, then stop
                // monitoring the window for changes.
                if (!images.length) {

                    stopWatchingWindow();
                }
            }
            // I clear the render timer so that we can easily 
            // check to see if the timer is running.
            function clearRenderTimer() {
                clearTimeout(renderTimer);
                renderTimer = null;
            }
            // I start the render time, allowing more images to
            // be added to the images queue before the render 
            // action is executed.
            function startRenderTimer() {
                renderTimer = setTimeout(checkImages, renderDelay);
            }
            // I start watching the window for changes in dimension.
            function startWatchingWindow() {
                isWatchingWindow = true;
                // Listen for window changes.
                win.on("resize.bnLazySrc", windowChanged);
                win.on("scroll.bnLazySrc", windowChanged);
                // Set up a timer to watch for document-height changes.
                documentTimer = setInterval(checkDocumentHeight, documentDelay);
            }
            // I stop watching the window for changes in dimension.
            function stopWatchingWindow() {
                isWatchingWindow = false;
                // Stop watching for window changes.
                win.off("resize.bnLazySrc");
                win.off("scroll.bnLazySrc");
                // Stop watching for document changes.
                clearInterval(documentTimer);
            }
            // I start the render time if the window changes.
            function windowChanged() {
                if (!renderTimer) {
                    startRenderTimer();
                }
            }
            // Return the public API.
            return ({
                addImage: addImage,
                removeImage: removeImage
            });
        })();
        // I represent a single lazy-load image.
        function LazyImage(element) {
            // I am the interpolated LAZY SRC attribute of 
            // the image as reported by AngularJS.					
            var source = null;
            // I determine if the image has already been 
            // rendered (ie, that it has been exposed to the
            // viewport and the source had been loaded).
            var isRendered = false;
            // I am the cached height of the element. We are 
            // going to assume that the image doesn't change 
            // height over time.
            var height = null;
            // I determine if the element is above the given 
            // fold of the page.
            function isVisible(topFoldOffset, bottomFoldOffset) {
                // If the element is not visible because it 
                // is hidden, don't bother testing it.
                if (!element.is(":visible")) {
                    return (false);
                }
                // If the height has not yet been calculated, 
                // the cache it for the duration of the page.
                if (height === null) {
                    height = element.height();
                }
                // Update the dimensions of the element.
                var top = element.offset().top;
                var bottom = (top + height);
                // Return true if the element is:
                // 1. The top offset is in view.
                // 2. The bottom offset is in view.
                // 3. The element is overlapping the viewport.
                return (
                    (
                        (top <= bottomFoldOffset) &&
                        (top >= topFoldOffset)
                    ) ||
                    (
                        (bottom <= bottomFoldOffset) &&
                        (bottom >= topFoldOffset)
                    ) ||
                    (
                        (top <= topFoldOffset) &&
                        (bottom >= bottomFoldOffset)
                    )
                );
            }
            // I move the cached source into the live source.
            function render() {
                isRendered = true;
                renderSource();
            }
            // I set the interpolated source value reported
            // by the directive / AngularJS.
            function setSource(newSource) {
                source = newSource;
                if (isRendered) {
                    renderSource();
                }
            }

            // I load the lazy source value into the actual 
            // source value of the image element.
            function renderSource() {
                element[0].src = source;
            }
            // Return the public API.
            return ({
                isVisible: isVisible,
                render: render,
                setSource: setSource
            });
        }
        // I bind the UI events to the scope.
        function link($scope, element, attributes) {
            var lazyImage = new LazyImage(element);
            // Start watching the image for changes in its
            // visibility.
            lazyLoader.addImage(lazyImage);
            // Since the lazy-src will likely need some sort
            // of string interpolation, we don't want to 
            attributes.$observe(
                "bnLazySrc",
                function(newSource) {
                    lazyImage.setSource(newSource);
                }
            );
            // When the scope is destroyed, we need to remove
            // the image from the render queue.
            $scope.$on(
                "$destroy",
                function() {
                    lazyLoader.removeImage(lazyImage);
                }
            );
        }
        // Return the directive configuration.
        return ({
            link: link,
            restrict: "A"
        });

    }
);

// OwlCarousel Settings

app.directive("owlCarousel", function() {
    return {
        restrict: 'E',
        transclude: false,
        link: function(scope) {
            scope.initCarousel = function(element) {
                // provide any default options you want
                var defaultOptions = {
                    /*autoPlay: 5000, 
                    stopOnHover: true,
                    slideSpeed : 300, ;*/
                    paginationSpeed : 400,
                    navigation : true,
                    navigationText: ['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
                    lazyLoad : true
					
                };

                var customOptions = scope.$eval($(element).attr('data-options'));
                // combine the two options objects
                for (var key in customOptions) {
                    defaultOptions[key] = customOptions[key];
                }

                // init carousel
                $(element).owlCarousel(defaultOptions)
                    //Check if already carousel made then destroy

            }

        }
    };
});

app.directive('owlCarouselItem', [function() {
    return {
        restrict: 'A',
        transclude: false,
        link: function(scope, element) {
            // wait for the last item in the ng-repeat then call init
            if (scope.$last) {
                scope.initCarousel(element.parent());

            }
        }
    };
}]);

// Template url

app.config(function($routeProvider) {
    $routeProvider
        .when("/", {
            templateUrl: "template/main.html"
        })
        .when("/product_category", {
            templateUrl: "template/product_category.html"
        })
        .when("/product_sub_category", {
            templateUrl: "template/product_sub_category.html"
        })
        .when("/product_sub_category_compare", {
            templateUrl: "template/product_sub_category_compare.html"
        })
        .when("/product_details_page", {
            templateUrl: "template/product_details_page.html"
        });
    /* .otherwise({
      redirectTo: '/'
    });*/

});